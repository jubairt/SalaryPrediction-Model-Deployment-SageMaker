import json
import joblib
import pandas as pd

# Load model
def model_fn(model_dir):
    model = joblib.load(f"{model_dir}/model.pkl")
    return model


# Parse input
def input_fn(request_body, content_type):
    if content_type != "application/json":
        raise ValueError("Unsupported content type")

    data = json.loads(request_body)

    # Ensure DataFrame format
    if isinstance(data, dict):
        data = pd.DataFrame(data)
    else:
        data = pd.DataFrame(data)

    return data


# Predict
def predict_fn(input_data, model):
    prediction = model.predict(input_data)
    return prediction


# Output
def output_fn(prediction, accept):
    return json.dumps(prediction.tolist())
